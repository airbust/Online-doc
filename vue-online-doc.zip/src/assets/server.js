import vue from "vue"
export default  new vue
